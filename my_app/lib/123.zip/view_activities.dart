import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ViewActivities extends StatefulWidget {
  const ViewActivities({Key? key}) : super(key: key);

  @override
  State<ViewActivities> createState() => _ViewActivitiesState();
}

class _ViewActivitiesState extends State<ViewActivities> {
  List _activities = [];

  Future<void> _fetchActivities() async {
    final email = Supabase.instance.client.auth.currentUser?.email;

    if (email == null) return;

    final response = await Supabase.instance.client
        .from('real_time_data')
        .select()
        .eq('user_email', email) // Filter by logged-in user
        .order('created_at', ascending: false);

    setState(() {
      _activities = response;
    });
  }

  @override
  void initState() {
    super.initState();
    _fetchActivities();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("My Activities")),
      body: _activities.isEmpty
          ? const Center(child: Text("No activities found."))
          : ListView.builder(
              itemCount: _activities.length,
              itemBuilder: (context, index) {
                final data = _activities[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  elevation: 3,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ListTile(
                    title: Text(data['description'] ?? 'No Description'),
                    subtitle: Text("Lat: ${data['latitude']}, Lng: ${data['longitude']}"),

                    trailing: Text(
                      (data['timestamp'] ?? '').toString().substring(0, 16),
                      style: const TextStyle(fontSize: 10),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
