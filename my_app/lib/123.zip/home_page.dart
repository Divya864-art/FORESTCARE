// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'dart:math';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'nasa_map.dart';
import 'package:latlong2/latlong.dart';

class HomePage extends StatefulWidget {
  final String userEmail;
  const HomePage({Key? key, required this.userEmail}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  String dailyTip = "Loading environmental tip...";
  List<Map<String, dynamic>> badges = [];
  List<Map<String, dynamic>> activities = [];
  List<Map<String, dynamic>> leaderboard = [];
  List<Map<String, dynamic>> events = [];

  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  final String adminEmail = "sujisujad@gmail.com";
  bool get isAdmin => widget.userEmail == adminEmail;

  final List<String> staticTips = [
    "🌱 Plant a tree this week.",
    "💧 Save water by fixing leaks.",
    "🚴 Use a bicycle for short trips.",
    "♻️ Recycle plastic and paper regularly.",
    "🌿 Take a walk in nature to refresh your mind."
  ];

  File? _capturedImage;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnimation = CurvedAnimation(parent: _controller, curve: Curves.easeIn);
    fetchAllData();
  }

  Future<void> fetchAllData() async {
    fetchRandomTip();
    fetchBadges();
    fetchRecentActivities();
    fetchLeaderboard();
    fetchEvents();
  }

  Future<void> _captureImage() async {
    final picker = ImagePicker();
    final XFile? photo = await picker.pickImage(source: ImageSource.camera);
    if (photo != null) {
      setState(() => _capturedImage = File(photo.path));
    }
  }

  Future<Position> _getUserLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) throw Exception('Location services are disabled.');

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) throw Exception('Location permissions are denied');
    }

    if (permission == LocationPermission.deniedForever) throw Exception('Location permissions are permanently denied');

    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }

  void fetchRandomTip() {
    final random = Random();
    setState(() {
      dailyTip = staticTips[random.nextInt(staticTips.length)];
      _controller.forward(from: 0);
    });
  }

  void fetchBadges() {
    setState(() {
      badges = [
        {"icon": "🏅", "name": "Tree Planter"},
        {"icon": "🌍", "name": "Earth Saver"},
        {"icon": "🔥", "name": "Fire Preventer"},
      ];
    });
  }

  void fetchRecentActivities() {
    setState(() {
      activities = [
        {"title": "Planted 5 Trees", "date": "2025-08-18"},
        {"title": "Attended Awareness Camp", "date": "2025-08-15"},
        {"title": "Cleaned Local Park", "date": "2025-08-12"},
      ];
    });
  }

  void fetchLeaderboard() {
    setState(() {
      leaderboard = [
        {"name": "Divya", "score": 120},
        {"name": "Suresh", "score": 95},
        {"name": "Priya", "score": 90},
        {"name": "Ravi", "score": 85},
        {"name": "Meena", "score": 80},
      ];
    });
  }

  void fetchEvents() {
    setState(() {
      events = [
        {"title": "Forest Awareness Drive", "date": "2025-08-25"},
        {"title": "Tree Plantation Day", "date": "2025-09-01"},
      ];
    });
  }

  Future<void> submitReport(String description, double lat, double lng) async {
    try {
      await Supabase.instance.client.from('real_time_data').insert({
        'description': description,
        'latitude': lat,
        'longitude': lng,
        'user_email': widget.userEmail,
        'created_at': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      debugPrint("Error submitting report: $e");
    }
  }

  void _logout(BuildContext context) => Navigator.pushReplacementNamed(context, '/');

  Widget buildSectionTitle(String title, Color color) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 12.0),
        child: Text(title, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      appBar: AppBar(title: const Text("Forest Care Dashboard"), backgroundColor: Colors.green[800]),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.green),
              child: Text("Welcome to ForestCare", style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(leading: const Icon(Icons.add_circle, color: Colors.green), title: const Text("Add Activity"), onTap: () => Navigator.pushNamed(context, '/add-activity')),
            ListTile(leading: const Icon(Icons.list, color: Colors.green), title: const Text("View My Activities"), onTap: () => Navigator.pushNamed(context, '/view-activities')),
            if (isAdmin)
              ListTile(
                  leading: const Icon(Icons.supervisor_account, color: Colors.deepPurple),
                  title: const Text("All User Activities"),
                  onTap: () => Navigator.pushNamed(context, '/all-activities')),
            if (isAdmin)
              ListTile(
                  leading: const Icon(Icons.assignment_ind, color: Colors.orange),
                  title: const Text("Assign Tasks to Officers"),
                  onTap: () => Navigator.pushNamed(context, '/assign-tasks')),
            ListTile(leading: const Icon(Icons.camera_alt, color: Colors.blue), title: const Text("Capture Image"), onTap: _captureImage),
           ListTile(
  leading: const Icon(Icons.public, color: Colors.blue),
  title: const Text("Report & View Map"),
  onTap: () async {
    try {
      // Get current location
      Position pos = await _getUserLocation();
      if (!mounted) return;

      // Fetch all reports from Supabase
      final reports = await Supabase.instance.client
    .from('real_time_data')
    .select<List<Map<String, dynamic>>>(
      'description, latitude, longitude, created_at, user_email',
    )
    .not('latitude', 'is', null) 
    .not('longitude','is',null)// ✅ filter out null latitudes
    .order('created_at', ascending: false) // ✅ this works
    .limit(1000);

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => NasaMap(
            reports: List<Map<String, dynamic>>.from(reports),
            userCenter: LatLng(pos.latitude, pos.longitude), // <--- FIX
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  },
),

            ListTile(leading: const Icon(Icons.logout, color: Colors.red), title: const Text("Logout"), onTap: () => _logout(context)),
          ],
        ),
      ),
      body: RefreshIndicator(
        onRefresh: fetchAllData,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16.0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text("Dashboard", style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.green)),
            const SizedBox(height: 20),
            _capturedImage == null ? const Text("No image captured yet.") : Image.file(_capturedImage!),
            const SizedBox(height: 16),
            FadeTransition(
              opacity: _fadeAnimation,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: Colors.lightGreen[100], borderRadius: BorderRadius.circular(12)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text(dailyTip, style: const TextStyle(fontSize: 16))),
                    IconButton(icon: const Icon(Icons.refresh, color: Colors.green), onPressed: fetchRandomTip),
                  ],
                ),
              ),
            ),
            buildSectionTitle("🏆 Your Badges", Colors.deepOrange),
            badges.isEmpty ? const Text("No badges earned yet.") : Wrap(spacing: 8, children: badges.map((b) => Chip(label: Text("${b['icon']} ${b['name']}"))).toList()),
            buildSectionTitle("📌 Recent Activities", Colors.blue),
            activities.isEmpty
                ? const Text("No recent activities found.")
                : Column(children: activities.map((a) => ListTile(leading: const Icon(Icons.check_circle, color: Colors.green), title: Text(a['title']), subtitle: Text(a['date']))).toList()),
            buildSectionTitle("🏅 Community Leaderboard", Colors.purple),
            leaderboard.isEmpty
                ? const Text("No leaderboard data yet.")
                : Column(children: leaderboard.map((l) => ListTile(leading: const Icon(Icons.star, color: Colors.amber), title: Text(l['name']), trailing: Text("${l['score']} Trees"))).toList()),
            buildSectionTitle("📅 Upcoming Events", Colors.teal),
            events.isEmpty ? const Text("No events scheduled.") : Column(children: events.map((e) => ListTile(leading: const Icon(Icons.event, color: Colors.orange), title: Text(e['title']), subtitle: Text(e['date']))).toList()),
          ]),
        ),
      ),
    );
  }
}
