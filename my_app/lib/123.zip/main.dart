
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'signup_page.dart';
import 'login_page.dart';
import 'home_page.dart';
import 'add_activity.dart';
import 'view_activities.dart';
import 'all_user_activities.dart';
import 'assign_tasks.dart';
import 'capture_incident.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://zobzammzikkcoaunmkvf.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpvYnphbW16aWtrY29hdW5ta3ZmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQzMDg1NTAsImV4cCI6MjA2OTg4NDU1MH0.9ZCdqYryQWbR99jLQXLjP-ksWvyzau8gSjhzIoNVk6g',
  );
  runApp(const ForestCareApp());
}

class ForestCareApp extends StatelessWidget {
  const ForestCareApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '🌿 Forest Care',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF1F8E9),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF2E7D32),
          elevation: 0,
          centerTitle: true,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
          iconTheme: IconThemeData(color: Colors.white),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green[700],
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ),
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
          filled: true,
          fillColor: Color(0xFFE8F5E9),
          labelStyle: TextStyle(color: Colors.black87),
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const LoginPage(),
        '/signup': (context) => const SignupPage(),
        '/home': (context) => const HomePage(userEmail: 'sujisujad@gmail.com'),
        '/add-activity': (context) => const AddActivity(userEmail: ''),
        '/view-activities': (context) => const ViewActivities(),
        '/all-activities': (context) => const AllUserActivities(), 
        '/assign-tasks': (context) => const AssignTasksPage(),
        '/capture-incident': (context) => const CaptureIncidentPage(officerId: 1), // Replace 1 with actual ID

      },
    );
  }
}