import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class NasaMap extends StatelessWidget {
  final List<Map<String, dynamic>> reports;
  final LatLng userCenter; // 👈 current user location

  const NasaMap({
    super.key,
    required this.reports,
    required this.userCenter,
  });

  @override
  Widget build(BuildContext context) {
    // Convert reports into red markers
    List<Marker> markers = reports.map((report) {
      final lat = (report['latitude'] as num?)?.toDouble() ?? 0.0;
      final lng = (report['longitude'] as num?)?.toDouble() ?? 0.0;
      final desc = report['description'] ?? "No description";
      final user = report['user_email'] ?? "Unknown";
      final time = (report['created_at'] ?? '').toString();
      
      return Marker(
        width: 50,
        height: 50,
        point: LatLng(lat, lng),
        child: GestureDetector(
          onTap: () {
            showDialog(
              context: context,
              builder: (_) => AlertDialog(
                title: const Text("Report Details"),
                content: Text("📍 $desc\n👤 $user\n🕒 $time"),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("Close"),
                  ),
                ],
              ),
            );
          },
          child: const Icon(Icons.location_pin, size: 40, color: Colors.red),
        ),
      );
    }).toList();

    // 👤 Add current user marker (blue)
    markers.add(
      Marker(
        width: 60,
        height: 60,
        point: userCenter,
        child: const Icon(Icons.person_pin_circle, size: 50, color: Colors.blue),
      ),
    );

    return Scaffold(
      appBar: AppBar(title: const Text("🌍 Community Map")),
      body: FlutterMap(
        options: MapOptions(
          initialCenter: userCenter, // 👈 Center map on user
          initialZoom: 7,
        ),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.example.forestcare',
          ),
          MarkerLayer(markers: markers),
        ],
      ),
    );
  }
}
