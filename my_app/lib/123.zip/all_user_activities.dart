import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AllUserActivities extends StatelessWidget {
  const AllUserActivities({Key? key}) : super(key: key);

  Future<List<Map<String, dynamic>>> fetchActivities() async {
    final response = await Supabase.instance.client
        .from('real_time_data')
        .select('*')
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(response);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("All Activities")),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: fetchActivities(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No activities found.'));
          }

          final activities = snapshot.data!;
          return ListView.builder(
            itemCount: activities.length,
            itemBuilder: (context, index) {
              final item = activities[index];
              final description = item['description'] ?? 'No description';
              final location = item['location'] ?? 'Unknown location';
              final user = item['user_email'] ?? 'Unknown user';
              final time = item['created_at']?.toString().split('.')[0] ?? 'Unknown time';

              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  leading: const Icon(Icons.nature),
                  title: Text(description),
                  subtitle: Text('Location: $location\nUser: $user\nTime: $time'),
                  isThreeLine: true,
                ),
              );
            },
          );
        },
      ),
    );
  }
}
