import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:geolocator/geolocator.dart';

class AddActivity extends StatelessWidget {
  final String userEmail;

  const AddActivity({Key? key, required this.userEmail}) : super(key: key);

  Future<Position> _getUserLocation(BuildContext context) async {
    bool serviceEnabled;
    LocationPermission permission;

    // Check location service
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enable location services')),
      );
      return Future.error('Location services disabled');
    }

    // Check permission
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Location permission denied')),
        );
        return Future.error('Permission denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Location permission permanently denied')),
      );
      return Future.error('Permission denied forever');
    }

    return await Geolocator.getCurrentPosition();
  }

  @override
  Widget build(BuildContext context) {
    final descController = TextEditingController();
    final locationController = TextEditingController(); // ✅ NEW

    void saveToSupabase() async {
      final desc = descController.text.trim();
      final location = locationController.text.trim();

      if (desc.isEmpty || location.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please enter description & location")),
        );
        return;
      }

      try {
        // Get current location (lat/lng)
        Position pos = await _getUserLocation(context);

        // Save to Supabase
        await Supabase.instance.client.from('real_time_data').insert({
          'description': desc,
          'location': location, // ✅ Add manual location
          'latitude': pos.latitude,
          'longitude': pos.longitude,
          'user_email': userEmail,
          'created_at': DateTime.now().toIso8601String(),
        });

        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Activity saved successfully")),
        );

        descController.clear();
        locationController.clear();
      } catch (e) {
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: $e")),
        );
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text("Add Activity")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: descController,
              decoration: const InputDecoration(labelText: 'Activity Description'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: locationController,
              decoration: const InputDecoration(labelText: 'Location (e.g. Chennai, Forest Area)'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: saveToSupabase,
              child: const Text("Save Activity with Location"),
            ),
          ],
        ),
      ),
    );
  }
}
