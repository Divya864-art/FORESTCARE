import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AssignTasksPage extends StatefulWidget {
  const AssignTasksPage({Key? key}) : super(key: key);

  @override
  State<AssignTasksPage> createState() => _AssignTasksPageState();
}

class _AssignTasksPageState extends State<AssignTasksPage> {
  final TextEditingController _taskController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();

  Map<String, dynamic>? selectedOfficer;
  List<Map<String, dynamic>> officers = [];

  @override
  void initState() {
    super.initState();
    _loadOfficers();
  }

  Future<void> _loadOfficers() async {
    try {
      final response = await Supabase.instance.client
          .from('officers')
          .select('id, email, role');

      final filtered = (response as List)
          .where((e) => e['role'] == 'officer')
          .map((e) => {'id': e['id'], 'email': e['email']})
          .toList();

      setState(() {
        officers = filtered;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to load officers: $e")),
      );
    }
  }

  Future<void> _assignTask() async {
    final task = _taskController.text.trim();
    final location = _locationController.text.trim();

    if (selectedOfficer != null && task.isNotEmpty && location.isNotEmpty) {
      try {
        await Supabase.instance.client.from('assigned_tasks').insert({
          'officer_id': selectedOfficer!['id'], // ✅ using ID now
          'task': task,
          'location': location,
          'assigned_at': DateTime.now().toIso8601String(),
        });

        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("✅ Task assigned successfully")),
        );

        _taskController.clear();
        _locationController.clear();
        setState(() {
          selectedOfficer = null;
        });
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to assign task: $e")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("⚠️ Select officer and fill all fields")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("🧑‍✈️ Assign Tasks to Forest Officers")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text("Select Officer:", style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            officers.isEmpty
                ? const Text("No officers found")
                : DropdownButton<Map<String, dynamic>>(
                    value: selectedOfficer,
                    hint: const Text("Choose officer"),
                    isExpanded: true,
                    onChanged: (value) {
                      setState(() {
                        selectedOfficer = value;
                      });
                    },
                    items: officers
                        .map((officer) => DropdownMenuItem<Map<String, dynamic>>(
                              value: officer,
                              child: Text(officer['email']),
                            ))
                        .toList(),
                  ),
            const SizedBox(height: 16),
            TextField(
              controller: _taskController,
              decoration: const InputDecoration(labelText: "Enter Task"),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _locationController,
              decoration: const InputDecoration(labelText: "Enter Location"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _assignTask,
              child: const Text("📩 Assign Task"),
            ),
          ],
        ),
      ),
    );
  }
}
