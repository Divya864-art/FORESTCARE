import 'dart:io' show File; // ✅ needed for mobile only
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CaptureIncidentPage extends StatefulWidget {
  const CaptureIncidentPage({super.key, required int officerId});

  @override
  State<CaptureIncidentPage> createState() => _CaptureIncidentPageState();
}

class _CaptureIncidentPageState extends State<CaptureIncidentPage> {
  Uint8List? _webImageBytes; // for web
  XFile? _pickedFile;        // for mobile & web
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage() async {
    final XFile? picked = await _picker.pickImage(source: ImageSource.camera);

    if (picked != null) {
      if (kIsWeb) {
        // ✅ on web: read as bytes
        final bytes = await picked.readAsBytes();
        setState(() {
          _webImageBytes = bytes;
          _pickedFile = picked;
        });
      } else {
        // ✅ on mobile: keep picked file
        setState(() {
          _pickedFile = picked;
        });
      }
    }
  }

  Future<void> _uploadImage() async {
    if (_pickedFile == null && _webImageBytes == null) return;

    try {
      final fileName = "${DateTime.now().millisecondsSinceEpoch}.jpg"; // ✅ interpolation

      if (kIsWeb) {
        // ✅ Upload bytes on web
        await Supabase.instance.client.storage
            .from("incident_photos")
            .uploadBinary(fileName, _webImageBytes!);
      } else {
        // ✅ Upload file on mobile
        final file = File(_pickedFile!.path); // convert XFile → File
        await Supabase.instance.client.storage
            .from("incident_photos")
            .upload(fileName, file);
      }

      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Upload successful ✅")),
      );
    } catch (e) {
      // ignore: use_build_context_synchronously
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Upload failed: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Capture Incident")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_webImageBytes != null)
              Image.memory(_webImageBytes!, height: 200)
            else if (_pickedFile != null && !kIsWeb)
              Image.file(
                File(_pickedFile!.path), // ✅ works only on mobile
                height: 200,
              ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _pickImage,
              child: const Text("Capture Image"),
            ),
            ElevatedButton(
              onPressed: _uploadImage,
              child: const Text("Upload to Supabase"),
            ),
          ],
        ),
      ),
    );
  }
}
